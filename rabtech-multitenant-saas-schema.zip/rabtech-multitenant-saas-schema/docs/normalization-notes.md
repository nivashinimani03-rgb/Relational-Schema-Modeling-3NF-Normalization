# Normalization Notes — Why This Schema Is in 3NF

A table is in 3rd Normal Form when it is in 2NF and every non-key
column depends on the whole primary key, and nothing but the key (no
transitive dependencies). Below is the functional-dependency reasoning
for all 8 tables.

## 1. tenants
`tenant_id → tenant_name, subdomain, plan, created_on`
All four attributes describe the tenant itself directly. No column
depends on another non-key column (e.g. `plan` doesn't determine
`subdomain`). **3NF.**

## 2. users
`user_id → tenant_id, email, full_name, role, joined_on`
Every attribute describes this specific user. `email` is unique *within*
`tenant_id` (`UNIQUE(tenant_id, email)`), not globally — that's a
business constraint, not a normalization issue: `email` still only
depends on `user_id`. **3NF.**

## 3. user_profiles
`user_id → phone, timezone, avatar_url`
This is the textbook 1:1 split: `user_profiles` holds optional/extended
attributes of a user, separated from the mandatory core `users` row so
that a user without a completed profile doesn't force nulls into the
primary `users` row. **3NF.**

## 4. teams
`team_id → tenant_id, team_name, created_on`
Same shape as `tenants` — direct attributes of the team. **3NF.**

## 5. team_members (junction: users ↔ teams)
`(team_id, user_id) → role_in_team, joined_on`
Composite key. `role_in_team` and `joined_on` describe *this specific
membership*, not the user alone or the team alone (the same user has a
different `role_in_team` on different teams — see Aarav Mehta in the
seed data: LEAD on Engineering, CONTRIBUTOR on Marketing). No partial
dependency on just `team_id` or just `user_id`. **3NF.**

## 6. projects
`project_id → tenant_id, team_id, project_name, status, created_on`
All direct attributes of the project. `team_id` is nullable (a project
can exist before it's assigned to a team), which is a business rule, not
a normalization concern. **3NF.**

## 7. tags
`tag_id → tenant_id, tag_name`
Direct attributes. `tag_name` is unique within a tenant
(`UNIQUE(tenant_id, tag_name)`) so two tenants can each have their own
"backend" tag without collision. **3NF.**

## 8. project_tags (junction: projects ↔ tags)
`(project_id, tag_id) → (nothing else)`
A pure many-to-many association with no descriptive attributes of its
own — this is the simplest possible 3NF junction table.

## Why tenant consistency is NOT a redundant column

It would be tempting to add a `tenant_id` column directly onto
`team_members` and `project_tags` to make cross-tenant checks a simple
`CHECK`. That column would be **transitively determined** by
`team_id → teams.tenant_id` (or `user_id → users.tenant_id`), which is
exactly the kind of redundancy 3NF exists to eliminate — it would let
`team_members.tenant_id` and `teams.tenant_id` drift out of sync on
update. Instead, cross-tenant consistency is enforced with `BEFORE
INSERT/UPDATE` triggers (see `schema.sql`) that look the tenant up
through the existing foreign keys rather than storing it a second time.
This keeps every table in strict 3NF while still making it impossible
to, say, tag a Northwind project with a Bluepeak tag.
