-- seed_data.sql
-- Realistic multi-row seed data for the multi-tenant SaaS schema.
-- Spans two tenants so cross-tenant isolation is actually demonstrable,
-- not just theoretical. Run after schema.sql.

BEGIN;

-- ---------------------------------------------------------------------
-- tenants
-- ---------------------------------------------------------------------
INSERT INTO tenants (tenant_id, tenant_name, subdomain, plan, created_on) VALUES
  (1, 'Northwind Retail',   'northwind', 'PRO',      '2026-01-05'),
  (2, 'Bluepeak Analytics', 'bluepeak',  'STARTER',  '2026-02-11');

-- ---------------------------------------------------------------------
-- users  (3 for tenant 1, 2 for tenant 2)
-- ---------------------------------------------------------------------
INSERT INTO users (user_id, tenant_id, email, full_name, role, joined_on) VALUES
  (1, 1, 'aarav@northwind.io',   'Aarav Mehta',  'OWNER',  '2026-01-05'),
  (2, 1, 'diya@northwind.io',    'Diya Nair',    'ADMIN',  '2026-01-12'),
  (3, 1, 'kabir@northwind.io',   'Kabir Shah',   'MEMBER', '2026-02-01'),
  (4, 2, 'meera@bluepeak.io',    'Meera Iyer',   'OWNER',  '2026-02-11'),
  (5, 2, 'rohan@bluepeak.io',    'Rohan Verma',  'MEMBER', '2026-02-20');

-- ---------------------------------------------------------------------
-- user_profiles  (1:1 with users)
-- ---------------------------------------------------------------------
INSERT INTO user_profiles (user_id, phone, timezone, avatar_url) VALUES
  (1, '+91-90000-00001', 'Asia/Kolkata', 'https://cdn.example.com/avatars/aarav.png'),
  (2, '+91-90000-00002', 'Asia/Kolkata', 'https://cdn.example.com/avatars/diya.png'),
  (3, NULL,              'Asia/Kolkata', NULL),
  (4, '+91-90000-00004', 'Asia/Kolkata', 'https://cdn.example.com/avatars/meera.png'),
  (5, NULL,              'Asia/Kolkata', NULL);

-- ---------------------------------------------------------------------
-- teams
-- ---------------------------------------------------------------------
INSERT INTO teams (team_id, tenant_id, team_name, created_on) VALUES
  (1, 1, 'Engineering', '2026-01-06'),
  (2, 1, 'Marketing',   '2026-01-20'),
  (3, 2, 'Data Science','2026-02-12');

-- ---------------------------------------------------------------------
-- team_members  (N:M users <-> teams)
-- ---------------------------------------------------------------------
INSERT INTO team_members (team_id, user_id, role_in_team, joined_on) VALUES
  (1, 1, 'LEAD',        '2026-01-06'),
  (1, 3, 'CONTRIBUTOR', '2026-02-01'),
  (2, 2, 'LEAD',        '2026-01-20'),
  (2, 1, 'CONTRIBUTOR', '2026-01-25'),  -- Aarav is on two teams
  (3, 4, 'LEAD',        '2026-02-12'),
  (3, 5, 'CONTRIBUTOR', '2026-02-20');

-- ---------------------------------------------------------------------
-- projects
-- ---------------------------------------------------------------------
INSERT INTO projects (project_id, tenant_id, team_id, project_name, status, created_on) VALUES
  (1, 1, 1, 'Checkout Revamp',        'ACTIVE',    '2026-01-10'),
  (2, 1, 1, 'API Rate Limiting',      'PLANNING',  '2026-02-05'),
  (3, 1, 2, 'Q1 Campaign Site',       'ON_HOLD',   '2026-01-25'),
  (4, 1, NULL, 'Internal Wiki Migration', 'COMPLETED', '2026-01-15'),
  (5, 2, 3, 'Churn Prediction Model', 'ACTIVE',    '2026-02-14');

-- ---------------------------------------------------------------------
-- tags
-- ---------------------------------------------------------------------
INSERT INTO tags (tag_id, tenant_id, tag_name) VALUES
  (1, 1, 'backend'),
  (2, 1, 'frontend'),
  (3, 1, 'marketing'),
  (4, 2, 'ml'),
  (5, 2, 'data-pipeline');

-- ---------------------------------------------------------------------
-- project_tags  (N:M projects <-> tags)
-- ---------------------------------------------------------------------
INSERT INTO project_tags (project_id, tag_id) VALUES
  (1, 1),   -- Checkout Revamp: backend
  (1, 2),   -- Checkout Revamp: frontend
  (2, 1),   -- API Rate Limiting: backend
  (3, 3),   -- Q1 Campaign Site: marketing
  (5, 4),   -- Churn Prediction Model: ml
  (5, 5);   -- Churn Prediction Model: data-pipeline

COMMIT;

-- Reset the SERIAL sequences past the explicit IDs above, so any
-- subsequent INSERT without an explicit id doesn't collide with seeded rows.
SELECT setval(pg_get_serial_sequence('tenants', 'tenant_id'), (SELECT MAX(tenant_id) FROM tenants));
SELECT setval(pg_get_serial_sequence('users', 'user_id'), (SELECT MAX(user_id) FROM users));
SELECT setval(pg_get_serial_sequence('teams', 'team_id'), (SELECT MAX(team_id) FROM teams));
SELECT setval(pg_get_serial_sequence('projects', 'project_id'), (SELECT MAX(project_id) FROM projects));
SELECT setval(pg_get_serial_sequence('tags', 'tag_id'), (SELECT MAX(tag_id) FROM tags));
