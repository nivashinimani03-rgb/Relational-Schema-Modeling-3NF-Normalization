-- schema.sql
-- RabTech Task 03: Relational Schema Modeling & 3NF Normalization
-- Domain: multi-tenant SaaS application (tenants, users, teams, projects, tags)
-- 8 tables covering 1:1, 1:N, and N:M relationships, all in strict 3NF
-- (every non-key column depends on the whole key, nothing but the key --
--  see docs/normalization-notes.md for the per-table functional
--  dependency analysis).
--
-- Written to be repeatable: guarded with IF NOT EXISTS so this file can
-- be re-run against a fresh database without error.

BEGIN;

-- ---------------------------------------------------------------------
-- 1. tenants  (root of the multi-tenant hierarchy)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tenants (
  tenant_id     SERIAL PRIMARY KEY,
  tenant_name   VARCHAR(120) NOT NULL,
  subdomain     VARCHAR(63)  NOT NULL UNIQUE,
  plan          VARCHAR(20)  NOT NULL DEFAULT 'FREE'
                CHECK (plan IN ('FREE', 'STARTER', 'PRO', 'ENTERPRISE')),
  created_on    DATE NOT NULL DEFAULT CURRENT_DATE
);

-- ---------------------------------------------------------------------
-- 2. users  (1:N  tenants -> users)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  user_id       SERIAL PRIMARY KEY,
  tenant_id     INTEGER NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
  email         VARCHAR(150) NOT NULL,
  full_name     VARCHAR(120) NOT NULL,
  role          VARCHAR(20)  NOT NULL DEFAULT 'MEMBER'
                CHECK (role IN ('OWNER', 'ADMIN', 'MEMBER')),
  joined_on     DATE NOT NULL DEFAULT CURRENT_DATE,
  UNIQUE (tenant_id, email)          -- email unique per tenant, not globally
);

-- ---------------------------------------------------------------------
-- 3. user_profiles  (1:1  users -> user_profiles)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user_profiles (
  user_id       INTEGER PRIMARY KEY REFERENCES users(user_id) ON DELETE CASCADE,
  phone         VARCHAR(20),
  timezone      VARCHAR(50) NOT NULL DEFAULT 'UTC',
  avatar_url    VARCHAR(255)
);

-- ---------------------------------------------------------------------
-- 4. teams  (1:N  tenants -> teams)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS teams (
  team_id       SERIAL PRIMARY KEY,
  tenant_id     INTEGER NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
  team_name     VARCHAR(100) NOT NULL,
  created_on    DATE NOT NULL DEFAULT CURRENT_DATE,
  UNIQUE (tenant_id, team_name)
);

-- ---------------------------------------------------------------------
-- 5. team_members  (N:M  users <-> teams, junction table)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS team_members (
  team_id       INTEGER NOT NULL REFERENCES teams(team_id) ON DELETE CASCADE,
  user_id       INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  role_in_team  VARCHAR(20) NOT NULL DEFAULT 'CONTRIBUTOR'
                CHECK (role_in_team IN ('LEAD', 'CONTRIBUTOR')),
  joined_on     DATE NOT NULL DEFAULT CURRENT_DATE,
  PRIMARY KEY (team_id, user_id)
);

-- ---------------------------------------------------------------------
-- 6. projects  (1:N  tenants -> projects, 1:N  teams -> projects)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS projects (
  project_id    SERIAL PRIMARY KEY,
  tenant_id     INTEGER NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
  team_id       INTEGER REFERENCES teams(team_id) ON DELETE SET NULL,
  project_name  VARCHAR(150) NOT NULL,
  status        VARCHAR(20) NOT NULL DEFAULT 'PLANNING'
                CHECK (status IN ('PLANNING', 'ACTIVE', 'ON_HOLD', 'COMPLETED')),
  created_on    DATE NOT NULL DEFAULT CURRENT_DATE
);

-- ---------------------------------------------------------------------
-- 7. tags  (1:N  tenants -> tags)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tags (
  tag_id        SERIAL PRIMARY KEY,
  tenant_id     INTEGER NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
  tag_name      VARCHAR(50) NOT NULL,
  UNIQUE (tenant_id, tag_name)
);

-- ---------------------------------------------------------------------
-- 8. project_tags  (N:M  projects <-> tags, junction table)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS project_tags (
  project_id    INTEGER NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
  tag_id        INTEGER NOT NULL REFERENCES tags(tag_id) ON DELETE CASCADE,
  PRIMARY KEY (project_id, tag_id)
);

COMMIT;

-- ---------------------------------------------------------------------
-- Cross-tenant referential-integrity triggers
-- ---------------------------------------------------------------------
-- A plain FK guarantees a team_id or tag_id exists somewhere, but not
-- that it belongs to the SAME tenant as the row referencing it -- that
-- is a multi-tenant-specific invariant, not expressible as a
-- single-table CHECK. Enforcing it with a trigger (rather than a
-- redundant tenant_id column on the junction/child tables) keeps every
-- table in strict 3NF -- see docs/normalization-notes.md.

BEGIN;

CREATE OR REPLACE FUNCTION enforce_same_tenant_project_team()
RETURNS TRIGGER AS $$
DECLARE
  v_team_tenant INTEGER;
BEGIN
  IF NEW.team_id IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT tenant_id INTO v_team_tenant FROM teams WHERE team_id = NEW.team_id;

  IF v_team_tenant IS DISTINCT FROM NEW.tenant_id THEN
    RAISE EXCEPTION
      'project_id % : team_id % belongs to tenant %, not project tenant %',
      NEW.project_id, NEW.team_id, v_team_tenant, NEW.tenant_id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_project_team_same_tenant ON projects;
CREATE TRIGGER trg_project_team_same_tenant
  BEFORE INSERT OR UPDATE OF team_id, tenant_id ON projects
  FOR EACH ROW
  EXECUTE FUNCTION enforce_same_tenant_project_team();


CREATE OR REPLACE FUNCTION enforce_same_tenant_team_member()
RETURNS TRIGGER AS $$
DECLARE
  v_team_tenant INTEGER;
  v_user_tenant INTEGER;
BEGIN
  SELECT tenant_id INTO v_team_tenant FROM teams WHERE team_id = NEW.team_id;
  SELECT tenant_id INTO v_user_tenant FROM users WHERE user_id = NEW.user_id;

  IF v_team_tenant IS DISTINCT FROM v_user_tenant THEN
    RAISE EXCEPTION
      'team_members: team_id % (tenant %) and user_id % (tenant %) belong to different tenants',
      NEW.team_id, v_team_tenant, NEW.user_id, v_user_tenant;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_team_member_same_tenant ON team_members;
CREATE TRIGGER trg_team_member_same_tenant
  BEFORE INSERT OR UPDATE OF team_id, user_id ON team_members
  FOR EACH ROW
  EXECUTE FUNCTION enforce_same_tenant_team_member();


CREATE OR REPLACE FUNCTION enforce_same_tenant_project_tag()
RETURNS TRIGGER AS $$
DECLARE
  v_project_tenant INTEGER;
  v_tag_tenant     INTEGER;
BEGIN
  SELECT tenant_id INTO v_project_tenant FROM projects WHERE project_id = NEW.project_id;
  SELECT tenant_id INTO v_tag_tenant     FROM tags     WHERE tag_id = NEW.tag_id;

  IF v_project_tenant IS DISTINCT FROM v_tag_tenant THEN
    RAISE EXCEPTION
      'project_tags: project_id % (tenant %) and tag_id % (tenant %) belong to different tenants',
      NEW.project_id, v_project_tenant, NEW.tag_id, v_tag_tenant;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_project_tag_same_tenant ON project_tags;
CREATE TRIGGER trg_project_tag_same_tenant
  BEFORE INSERT OR UPDATE OF project_id, tag_id ON project_tags
  FOR EACH ROW
  EXECUTE FUNCTION enforce_same_tenant_project_tag();

COMMIT;
